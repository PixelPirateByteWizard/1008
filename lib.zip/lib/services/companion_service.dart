import 'package:shared_preferences/shared_preferences.dart' as prefs;
import '../models/virtual_companion.dart';
import 'dart:convert';

class CompanionService {
  static const String _storageKey = 'added_companions';
  static final CompanionService _instance = CompanionService._internal();

  factory CompanionService() {
    return _instance;
  }

  CompanionService._internal();

  Future<List<String>> getAddedCompanionIds() async {
    final prefs.SharedPreferences preferences =
        await prefs.SharedPreferences.getInstance();
    return preferences.getStringList(_storageKey) ?? [];
  }

  Future<void> addCompanion(String companionId) async {
    final prefs.SharedPreferences preferences =
        await prefs.SharedPreferences.getInstance();
    final List<String> currentIds = await getAddedCompanionIds();
    if (!currentIds.contains(companionId)) {
      currentIds.add(companionId);
      await preferences.setStringList(_storageKey, currentIds);
    }
  }

  Future<void> removeCompanion(String companionId) async {
    final prefs.SharedPreferences preferences =
        await prefs.SharedPreferences.getInstance();
    final List<String> currentIds = await getAddedCompanionIds();
    currentIds.remove(companionId);
    await preferences.setStringList(_storageKey, currentIds);
  }
}
