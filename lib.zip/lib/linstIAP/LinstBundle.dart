class LinstBundle {
  final String itemId;
  final String name;
  final String type;
  final int coinAmount;
  final String price;
  final String description;
  final String locale;
  final String category;

  const LinstBundle({
    required this.itemId,
    required this.name,
    required this.type,
    required this.coinAmount,
    required this.price,
    required this.description,
    required this.locale,
    required this.category,
  });
}

const List<LinstBundle> shopInventory = <LinstBundle>[
  LinstBundle(
    itemId: 'com.uuidflutter.test.1',
    name: 'Black Iron',
    type: 'basic',
    coinAmount: 100,
    price: '0.99',
    description: 'Black Iron',
    locale: 'en_US',
    category: 'basic',
  ),
  // Regular Items
  LinstBundle(
    itemId: '599100',
    name: 'Black Iron',
    type: 'basic',
    coinAmount: 100,
    price: '0.99',
    description: 'Black Iron',
    locale: 'en_US',
    category: 'basic',
  ),
  LinstBundle(
    itemId: '599101',
    name: 'Bronze',
    type: 'basic',
    coinAmount: 500,
    price: '4.99',
    description: 'Bronze',
    locale: 'en_US',
    category: 'basic',
  ),
  LinstBundle(
    itemId: '599102',
    name: 'Silver',
    type: 'basic',
    coinAmount: 1200,
    price: '9.99',
    description: 'Silver',
    locale: 'en_US',
    category: 'basic',
  ),
  LinstBundle(
    itemId: '599103',
    name: 'Titanium',
    type: 'basic',
    coinAmount: 2500,
    price: '19.99',
    description: 'Titanium',
    locale: 'en_US',
    category: 'basic',
  ),
  LinstBundle(
    itemId: '599104',
    name: 'Gold',
    type: 'basic',
    coinAmount: 7000,
    price: '49.99',
    description: 'Gold',
    locale: 'en_US',
    category: 'basic',
  ),
  LinstBundle(
    itemId: '599105',
    name: 'Platinum',
    type: 'basic',
    coinAmount: 15000,
    price: '99.99',
    description: 'Platinum',
    locale: 'en_US',
    category: 'basic',
  ),

  // Promotional Items
  LinstBundle(
    itemId: '599106',
    name: 'Great Deals-Bronze',
    type: 'promotion',
    coinAmount: 500,
    price: '1.99',
    description: 'Great Deals-Bronze',
    locale: 'en_US',
    category: 'promotion',
  ),
  LinstBundle(
    itemId: '599107',
    name: 'Great Deals-Silver',
    type: 'promotion',
    coinAmount: 1200,
    price: '4.99',
    description: 'Great Deals-Silver',
    locale: 'en_US',
    category: 'promotion',
  ),
  LinstBundle(
    itemId: '599108',
    name: 'Great Deals-Titanium',
    type: 'promotion',
    coinAmount: 2500,
    price: '11.99',
    description: 'Great Deals-Titanium',
    locale: 'en_US',
    category: 'promotion',
  ),
  LinstBundle(
    itemId: '599109',
    name: 'Great Deals-Gold',
    type: 'promotion',
    coinAmount: 7000,
    price: '34.99',
    description: 'Great Deals-Gold',
    locale: 'en_US',
    category: 'promotion',
  ),
  LinstBundle(
    itemId: '599110',
    name: 'Great Deals-Platinum',
    type: 'promotion',
    coinAmount: 15000,
    price: '79.99',
    description: 'Great Deals-Platinum',
    locale: 'en_US',
    category: 'promotion',
  ),
];
