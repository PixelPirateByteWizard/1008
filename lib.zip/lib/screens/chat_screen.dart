import 'package:flutter/material.dart';
import 'dart:ui';
import '../models/virtual_companion.dart';
import '../models/ai_assistant_service.dart';
import '../models/chat_message.dart';
import '../screens/companion_profile_screen.dart';
import '../screens/video_call_screen.dart';

class ChatScreen extends StatefulWidget {
  final VirtualCompanion companion;
  final List<ChatMessage> previousMessages;

  const ChatScreen({
    super.key,
    required this.companion,
    this.previousMessages = const [],
  });

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final TextEditingController _messageController = TextEditingController();
  late List<ChatMessage> _messages;
  final AIAssistantService _aiService = AIAssistantService();
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    _messages = [...widget.previousMessages];
  }

  @override
  void dispose() {
    _messageController.dispose();
    _aiService.terminate();
    super.dispose();
  }

  Future<void> _handleSendMessage() async {
    final message = _messageController.text.trim();
    if (message.isEmpty) return;

    setState(() {
      _messages.add(ChatMessage(
        message: message,
        isUser: true,
      ));
      _isLoading = true;
    });
    _messageController.clear();

    try {
      final prompt = '''
Chat with ${widget.companion.displayName}.
Your personality traits: ${widget.companion.passionForLife}
Please respond to the user's message naturally:
$message
''';

      final response = await _aiService.sendQuery(prompt);

      if (mounted) {
        setState(() {
          _messages.add(ChatMessage(
            message: response,
            isUser: false,
          ));
          _isLoading = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _messages.add(ChatMessage(
            message:
                "Sorry, I can't respond right now. Please try again later.",
            isUser: false,
          ));
          _isLoading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        extendBodyBehindAppBar: true,
        appBar: AppBar(
          elevation: 0,
          backgroundColor: Colors.transparent,
          flexibleSpace: ClipRect(
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
              child: Container(
                color: const Color(0xFF1C1C1E).withOpacity(0.7),
              ),
            ),
          ),
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios, color: Color(0xFFE0C9A6)),
            onPressed: () => Navigator.of(context).pop(),
          ),
          title: Row(
            children: [
              _buildCompanionAvatar(),
              const SizedBox(width: 12),
              _buildCompanionInfo(),
            ],
          ),
          actions: [
            IconButton(
              icon: const Icon(
                Icons.videocam_outlined,
                color: Color(0xFFE0C9A6),
              ),
              onPressed: () {
                Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (context) => VideoCallScreen(
                      companion: widget.companion,
                    ),
                  ),
                );
              },
            ),
            IconButton(
              icon: const Icon(
                Icons.more_horiz,
                color: Color(0xFFE0C9A6),
              ),
              onPressed: () {
                showModalBottomSheet(
                  context: context,
                  backgroundColor: Colors.transparent,
                  builder: (context) => _buildMoreOptionsSheet(),
                );
              },
            ),
          ],
        ),
        body: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                const Color(0xFF1C1C1E),
                const Color(0xFF2C2C2E),
              ],
            ),
          ),
          child: Column(
            children: [
              Expanded(
                child: _buildMessagesList(),
              ),
              _buildInputArea(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildCompanionAvatar() {
    return Hero(
      tag: 'companion_${widget.companion.identifier}',
      child: GestureDetector(
        onTap: () => Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => CompanionProfileScreen(
              companion: widget.companion,
            ),
          ),
        ),
        child: Container(
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            border: Border.all(
              color: const Color(0xFFE0C9A6).withOpacity(0.3),
              width: 2,
            ),
            boxShadow: [
              BoxShadow(
                color: const Color(0xFFE0C9A6).withOpacity(0.2),
                blurRadius: 8,
              ),
            ],
          ),
          child: CircleAvatar(
            radius: 20,
            backgroundImage: AssetImage(widget.companion.profileImagePath),
          ),
        ),
      ),
    );
  }

  Widget _buildCompanionInfo() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          widget.companion.displayName,
          style: const TextStyle(
            color: Color(0xFFE0C9A6),
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
        Row(
          children: [
            Container(
              width: 8,
              height: 8,
              decoration: BoxDecoration(
                color: Colors.greenAccent,
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: Colors.greenAccent.withOpacity(0.5),
                    blurRadius: 4,
                  ),
                ],
              ),
            ),
            const SizedBox(width: 4),
            Text(
              'Online',
              style: TextStyle(
                color: const Color(0xFFE0C9A6).withOpacity(0.7),
                fontSize: 12,
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildMessagesList() {
    return ListView.builder(
      reverse: true,
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
      itemCount: _messages.length + (_isLoading ? 1 : 0),
      itemBuilder: (context, index) {
        if (_isLoading && index == 0) {
          return TypingIndicator(companion: widget.companion);
        }
        final messageIndex = _isLoading ? index - 1 : index;
        final message = _messages[_messages.length - 1 - messageIndex];
        return ChatBubble(
          message: message,
          companion: widget.companion,
          showTime: true,
        );
      },
    );
  }

  Widget _buildInputArea() {
    return Container(
      margin: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF2C2C2E).withOpacity(0.9),
        borderRadius: BorderRadius.circular(30),
        border: Border.all(
          color: const Color(0xFFE0C9A6).withOpacity(0.2),
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.2),
            blurRadius: 20,
          ),
        ],
      ),
      child: Row(
        children: [
          IconButton(
            icon: const Icon(Icons.emoji_emotions_outlined),
            color: const Color(0xFFE0C9A6).withOpacity(0.7),
            onPressed: () {
              // TODO: Implement emoji picker
            },
          ),
          Expanded(
            child: TextField(
              controller: _messageController,
              style: const TextStyle(color: Color(0xFFE0C9A6)),
              maxLines: null,
              decoration: InputDecoration(
                hintText: 'Type a message...',
                hintStyle: TextStyle(
                  color: const Color(0xFFE0C9A6).withOpacity(0.5),
                ),
                border: InputBorder.none,
                contentPadding: const EdgeInsets.symmetric(horizontal: 16),
              ),
            ),
          ),
          AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            child: IconButton(
              onPressed: _isLoading ? null : _handleSendMessage,
              icon: const Icon(Icons.send_rounded),
              color: _isLoading
                  ? const Color(0xFFE0C9A6).withOpacity(0.5)
                  : const Color(0xFFE0C9A6),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMoreOptionsSheet() {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF1C1C1E),
        borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.2),
            blurRadius: 10,
            offset: const Offset(0, -2),
          ),
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            margin: const EdgeInsets.only(top: 8),
            width: 40,
            height: 4,
            decoration: BoxDecoration(
              color: const Color(0xFFE0C9A6).withOpacity(0.3),
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                ListTile(
                  leading: Icon(
                    Icons.delete_outline,
                    color: const Color(0xFFE0C9A6).withOpacity(0.8),
                  ),
                  title: Text(
                    'Clear Chat History',
                    style: TextStyle(
                      color: const Color(0xFFE0C9A6).withOpacity(0.8),
                      fontSize: 16,
                    ),
                  ),
                  onTap: () {
                    // TODO: Implement clear chat history
                    Navigator.pop(context);
                  },
                ),
                ListTile(
                  leading: Icon(
                    Icons.block_outlined,
                    color: const Color(0xFFE0C9A6).withOpacity(0.8),
                  ),
                  title: Text(
                    'Block Companion',
                    style: TextStyle(
                      color: const Color(0xFFE0C9A6).withOpacity(0.8),
                      fontSize: 16,
                    ),
                  ),
                  onTap: () {
                    // TODO: Implement block companion
                    Navigator.pop(context);
                  },
                ),
                ListTile(
                  leading: Icon(
                    Icons.report_outlined,
                    color: const Color(0xFFE0C9A6).withOpacity(0.8),
                  ),
                  title: Text(
                    'Report Issue',
                    style: TextStyle(
                      color: const Color(0xFFE0C9A6).withOpacity(0.8),
                      fontSize: 16,
                    ),
                  ),
                  onTap: () {
                    // TODO: Implement report issue
                    Navigator.pop(context);
                  },
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class ChatBubble extends StatelessWidget {
  final ChatMessage message;
  final VirtualCompanion companion;
  final bool showTime;

  const ChatBubble({
    super.key,
    required this.message,
    required this.companion,
    this.showTime = false,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Column(
        crossAxisAlignment:
            message.isUser ? CrossAxisAlignment.end : CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: message.isUser
                ? MainAxisAlignment.end
                : MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              if (!message.isUser) ...[
                _buildAvatar(),
                const SizedBox(width: 8),
              ],
              Flexible(
                child: Container(
                  constraints: BoxConstraints(
                    maxWidth: MediaQuery.of(context).size.width * 0.75,
                  ),
                  padding: const EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 12,
                  ),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: message.isUser
                          ? [
                              const Color(0xFFB8860B).withOpacity(0.9),
                              const Color(0xFFB8860B).withOpacity(0.7),
                            ]
                          : [
                              const Color(0xFF2C2C2E).withOpacity(0.9),
                              const Color(0xFF2C2C2E).withOpacity(0.7),
                            ],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(20).copyWith(
                      bottomLeft: Radius.circular(!message.isUser ? 0 : 20),
                      bottomRight: Radius.circular(message.isUser ? 0 : 20),
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.1),
                        blurRadius: 8,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Text(
                    message.message,
                    style: TextStyle(
                      color: const Color(0xFFE0C9A6),
                      fontSize: 15,
                      height: 1.4,
                    ),
                  ),
                ),
              ),
            ],
          ),
          if (showTime) ...[
            const SizedBox(height: 4),
            Padding(
              padding: EdgeInsets.only(
                left: message.isUser ? 0 : 48,
                right: message.isUser ? 8 : 0,
              ),
              child: Text(
                '12:34 PM', // TODO: Add actual timestamp
                style: TextStyle(
                  color: const Color(0xFFE0C9A6).withOpacity(0.5),
                  fontSize: 11,
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildAvatar() {
    return GestureDetector(
      onTap: () {},
      child: Container(
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          border: Border.all(
            color: const Color(0xFFE0C9A6).withOpacity(0.3),
            width: 2,
          ),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFFE0C9A6).withOpacity(0.2),
              blurRadius: 8,
            ),
          ],
        ),
        child: CircleAvatar(
          radius: 20,
          backgroundImage: AssetImage(companion.profileImagePath),
        ),
      ),
    );
  }
}

class TypingIndicator extends StatefulWidget {
  final VirtualCompanion companion;

  const TypingIndicator({
    super.key,
    required this.companion,
  });

  @override
  State<TypingIndicator> createState() => _TypingIndicatorState();
}

class _TypingIndicatorState extends State<TypingIndicator>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  final List<Animation<double>> _dotAnimations = [];

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat();

    for (int i = 0; i < 3; i++) {
      _dotAnimations.add(
        Tween<double>(begin: 0, end: 1).animate(
          CurvedAnimation(
            parent: _controller,
            curve: Interval(
              i * 0.2,
              0.6 + i * 0.2,
              curve: Curves.easeInOut,
            ),
          ),
        ),
      );
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(8),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          CircleAvatar(
            radius: 16,
            backgroundImage: AssetImage(widget.companion.profileImagePath),
          ),
          const SizedBox(width: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: BoxDecoration(
              color: const Color(0xFF2C2C2E),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: List.generate(3, (index) {
                return AnimatedBuilder(
                  animation: _controller,
                  builder: (context, child) {
                    return Container(
                      width: 8,
                      height: 8,
                      margin: const EdgeInsets.symmetric(horizontal: 2),
                      decoration: BoxDecoration(
                        color: Color(0xFFE0C9A6).withOpacity(
                          _dotAnimations[index].value,
                        ),
                        shape: BoxShape.circle,
                      ),
                    );
                  },
                );
              }),
            ),
          ),
        ],
      ),
    );
  }
}
