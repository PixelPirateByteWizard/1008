import 'package:flutter/material.dart';
import 'dart:async';
import 'dart:math';
import '../data/companion_profiles.dart';
import '../models/virtual_companion.dart';
import '../screens/discussion_chat_screen.dart';
import '../screens/companion_profile_screen.dart';

class GroupChatScreen extends StatefulWidget {
  const GroupChatScreen({super.key});

  @override
  State<GroupChatScreen> createState() => _GroupChatScreenState();
}

class _GroupChatScreenState extends State<GroupChatScreen> {
  final List<ChatMessage> messages = [];
  final ScrollController _scrollController = ScrollController();
  Timer? _messageTimer;
  final Random _random = Random();
  final TextEditingController _textController = TextEditingController();
  bool _showChatInput = false;
  VirtualCompanion? _lastMessageSender;
  final Map<String, DateTime> _lastMessageTimes = {};
  static const Duration _minimumMessageInterval = Duration(seconds: 10);

  @override
  void initState() {
    super.initState();
    _startMessageTimer();
  }

  @override
  void dispose() {
    _messageTimer?.cancel();
    _scrollController.dispose();
    _textController.dispose();
    super.dispose();
  }

  void _startMessageTimer() {
    _messageTimer = Timer.periodic(const Duration(seconds: 3), (timer) {
      _sendRandomMessage();
    });
  }

  void _sendRandomMessage() {
    if (!mounted) return;

    final now = DateTime.now();

    final availableCompanions = companionProfiles.where((companion) {
      final lastMessageTime = _lastMessageTimes[companion.identifier];
      if (lastMessageTime == null) return true;
      return now.difference(lastMessageTime) >= _minimumMessageInterval;
    }).toList();

    if (availableCompanions.isEmpty) {
      _messageTimer?.cancel();
      _messageTimer = Timer(
        const Duration(seconds: 2),
        _startMessageTimer,
      );
      return;
    }

    final companion =
        availableCompanions[_random.nextInt(availableCompanions.length)];
    _lastMessageTimes[companion.identifier] = now;

    final messageType =
        _random.nextInt(3); // 0: welcome, 1: biography, 2: passion

    setState(() {
      if (messages.length >= 30) {
        messages.removeAt(0);
      }

      switch (messageType) {
        case 0:
          messages.add(ChatMessage(
            companion: companion,
            message: companion.welcomeMessage,
            isCard: false,
          ));
        case 1:
          messages.add(ChatMessage(
            companion: companion,
            message: companion.biography,
            isCard: false,
          ));
        case 2:
          messages.add(ChatMessage(
            companion: companion,
            message: companion.passionForLife,
            isCard: true,
          ));
      }
    });

    _messageTimer?.cancel();
    _messageTimer = Timer(
      Duration(seconds: _random.nextInt(50) + 10), // 10-60秒
      _startMessageTimer,
    );

    WidgetsBinding.instance.addPostFrameCallback((_) {
      _scrollController.animateTo(
        _scrollController.position.maxScrollExtent,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeOut,
      );
    });
  }

  void _handleSendMessage() {
    if (_textController.text.trim().isEmpty) return;

    setState(() {
      if (messages.length >= 30) {
        messages.removeAt(0);
      }

      messages.add(ChatMessage(
        companion: VirtualCompanion(
          identifier: 'user',
          displayName: 'You',
          profileImagePath: 'placeholder_for_user_icon',
          description: 'User',
          characterTrait: 'User',
          hobbies: ['Chatting'],
          welcomeMessage: '',
          biography: '',
          communicationStyle: 'Direct',
          lifeStories: '',
          passionForLife: '',
        ),
        message: _textController.text,
        isCard: false,
      ));
      _textController.clear();
    });

    WidgetsBinding.instance.addPostFrameCallback((_) {
      _scrollController.animateTo(
        _scrollController.position.maxScrollExtent,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeOut,
      );
    });
  }

  void _showHelpDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return Dialog(
          backgroundColor: const Color(0xFF2C2C2E),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(
                      Icons.help_outline_rounded,
                      color: const Color(0xFFE0C9A6),
                      size: 24,
                    ),
                    const SizedBox(width: 12),
                    Text(
                      'How to Use',
                      style: TextStyle(
                        color: const Color(0xFFE0C9A6),
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20),
                _buildHelpItem(
                  icon: Icons.remove_red_eye,
                  title: 'Watch AI Interactions',
                  description:
                      'Observe AI companions engaging in natural conversations.',
                ),
                const SizedBox(height: 16),
                _buildHelpItem(
                  icon: Icons.chat_bubble_outline,
                  title: 'Join the Chat',
                  description:
                      'Click the chat button to participate in the conversation.',
                ),
                const SizedBox(height: 16),
                _buildHelpItem(
                  icon: Icons.psychology_outlined,
                  title: 'Discussion Topics',
                  description:
                      'Click "Join Discussion" on topic cards to start a focused conversation.',
                ),
                const SizedBox(height: 16),
                _buildHelpItem(
                  icon: Icons.person_outline,
                  title: 'Companion Profiles',
                  description:
                      'Tap on companion avatars to view their detailed profiles.',
                ),
                const SizedBox(height: 24),
                Align(
                  alignment: Alignment.centerRight,
                  child: TextButton(
                    onPressed: () => Navigator.of(context).pop(),
                    child: Text(
                      'Got it',
                      style: TextStyle(
                        color: const Color(0xFFE0C9A6),
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildHelpItem({
    required IconData icon,
    required String title,
    required String description,
  }) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: const Color(0xFFE0C9A6).withOpacity(0.1),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Icon(
            icon,
            size: 20,
            color: const Color(0xFFE0C9A6),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: TextStyle(
                  color: const Color(0xFFE0C9A6),
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                description,
                style: TextStyle(
                  color: const Color(0xFFE0C9A6).withOpacity(0.7),
                  fontSize: 14,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: () {
          FocusScope.of(context).unfocus();
          setState(() => _showChatInput = false);
        },
        child: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                const Color(0xFF1C1C1E),
                const Color(0xFF2C2C2E),
              ],
            ),
          ),
          child: SafeArea(
            child: Stack(
              children: [
                Column(
                  children: [
                    const SizedBox(height: 24),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 24),
                      child: Row(
                        children: [
                          Text(
                            'AI Group Chat',
                            style: Theme.of(context)
                                .textTheme
                                .headlineMedium
                                ?.copyWith(
                                  fontWeight: FontWeight.w600,
                                  color: const Color(0xFFE0C9A6),
                                  letterSpacing: 1.2,
                                ),
                          ),
                          const Spacer(),
                          Container(
                            decoration: BoxDecoration(
                              color: const Color(0xFFE0C9A6).withOpacity(0.1),
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(
                                color: const Color(0xFFE0C9A6).withOpacity(0.2),
                                width: 1,
                              ),
                            ),
                            child: IconButton(
                              onPressed: _showHelpDialog,
                              icon: const Icon(
                                Icons.help_outline_rounded,
                                color: Color(0xFFE0C9A6),
                                size: 20,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 8),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 24),
                      child: Text(
                        'Watch AI companions interact with each other',
                        style: Theme.of(context)
                            .textTheme
                            .titleMedium
                            ?.copyWith(
                              color: const Color(0xFFE0C9A6).withOpacity(0.7),
                              letterSpacing: 0.5,
                            ),
                      ),
                    ),
                    const SizedBox(height: 24),
                    Expanded(
                      child: ListView.builder(
                        controller: _scrollController,
                        padding: const EdgeInsets.all(16),
                        itemCount: messages.length,
                        itemBuilder: (context, index) {
                          final message = messages[index];
                          return _buildMessageItem(message);
                        },
                      ),
                    ),
                    if (_showChatInput) _buildChatInput(),
                  ],
                ),
                if (!_showChatInput)
                  Positioned(
                    right: 16,
                    bottom: 16,
                    child: FloatingActionButton(
                      backgroundColor: const Color(0xFFE0C9A6),
                      child: const Icon(Icons.chat_bubble_outline,
                          color: Color(0xFF1C1C1E)),
                      onPressed: () => setState(() => _showChatInput = true),
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildMessageItem(ChatMessage message) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: message.companion.identifier == 'user'
            ? MainAxisAlignment.end
            : MainAxisAlignment.start,
        children: [
          if (message.companion.identifier != 'user') ...[
            _buildAvatar(message),
            const SizedBox(width: 12),
          ],
          Expanded(
            child: Column(
              crossAxisAlignment: message.companion.identifier == 'user'
                  ? CrossAxisAlignment.end
                  : CrossAxisAlignment.start,
              children: [
                Text(
                  message.companion.displayName,
                  style: const TextStyle(
                    color: Color(0xFFE0C9A6),
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                    letterSpacing: 0.5,
                  ),
                ),
                const SizedBox(height: 4),
                if (!message.isCard)
                  _buildMessageBubble(
                      message.message, message.companion.identifier == 'user')
                else
                  _buildMessageCard(message),
              ],
            ),
          ),
          if (message.companion.identifier == 'user') ...[
            const SizedBox(width: 12),
            _buildAvatar(message),
          ],
        ],
      ),
    );
  }

  Widget _buildAvatar(ChatMessage message) {
    return GestureDetector(
      onTap: () {
        if (message.companion.identifier != 'user') {
          Navigator.of(context).push(
            MaterialPageRoute(
              builder: (context) => CompanionProfileScreen(
                companion: message.companion,
              ),
            ),
          );
        }
      },
      child: Container(
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          border: Border.all(
            color: const Color(0xFFE0C9A6).withOpacity(0.3),
            width: 2,
          ),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFFE0C9A6).withOpacity(0.1),
              blurRadius: 10,
              spreadRadius: 2,
            ),
          ],
        ),
        child: message.companion.identifier == 'user'
            ? CircleAvatar(
                backgroundColor: const Color(0xFF2C2C2E),
                radius: 20,
                child: Icon(
                  Icons.person,
                  color: const Color(0xFFE0C9A6),
                  size: 24,
                ),
              )
            : Hero(
                tag: 'companion_image_${message.companion.identifier}',
                child: CircleAvatar(
                  backgroundImage:
                      AssetImage(message.companion.profileImagePath),
                  radius: 20,
                ),
              ),
      ),
    );
  }

  Widget _buildMessageBubble(String message, bool isUserMessage) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color:
            isUserMessage ? const Color(0xFFE0C9A6) : const Color(0xFF2C2C2E),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: const Color(0xFFE0C9A6).withOpacity(0.15),
          width: 0.5,
        ),
      ),
      child: Text(
        message,
        style: TextStyle(
          color:
              isUserMessage ? const Color(0xFF1C1C1E) : const Color(0xFFE0C9A6),
          fontSize: 14,
          height: 1.5,
          letterSpacing: 0.3,
        ),
      ),
    );
  }

  Widget _buildMessageCard(ChatMessage chatMessage) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            const Color(0xFF2C2C2E),
            const Color(0xFF1C1C1E),
          ],
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: const Color(0xFFE0C9A6).withOpacity(0.15),
          width: 0.5,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: const Color(0xFFE0C9A6).withOpacity(0.1),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: const Icon(
                        Icons.psychology_outlined,
                        size: 16,
                        color: Color(0xFFE0C9A6),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Text(
                      'Thought-Provoking Topic',
                      style: TextStyle(
                        color: const Color(0xFFE0C9A6),
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                        letterSpacing: 0.5,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Text(
                  chatMessage.message,
                  style: TextStyle(
                    color: const Color(0xFFE0C9A6).withOpacity(0.9),
                    fontSize: 15,
                    height: 1.5,
                    letterSpacing: 0.3,
                  ),
                ),
              ],
            ),
          ),
          Container(
            height: 1,
            color: const Color(0xFFE0C9A6).withOpacity(0.1),
          ),
          InkWell(
            onTap: () {
              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (context) => DiscussionChatScreen(
                    companion: chatMessage.companion,
                    initialTopic: chatMessage.message,
                  ),
                ),
              );
            },
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(
                    Icons.chat_bubble_outline,
                    size: 20,
                    color: Color(0xFFE0C9A6),
                  ),
                  const SizedBox(width: 8),
                  Text(
                    'Join Discussion',
                    style: TextStyle(
                      color: const Color(0xFFE0C9A6),
                      fontWeight: FontWeight.w600,
                      fontSize: 14,
                      letterSpacing: 0.5,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildChatInput() {
    return GestureDetector(
      onTap: () {
        return;
      },
      child: Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: const Color(0xFF2C2C2E),
          border: Border(
            top: BorderSide(
              color: const Color(0xFFE0C9A6).withOpacity(0.15),
              width: 0.5,
            ),
          ),
        ),
        child: Row(
          children: [
            IconButton(
              icon: const Icon(Icons.close, color: Color(0xFFE0C9A6)),
              onPressed: () => setState(() => _showChatInput = false),
            ),
            Expanded(
              child: TextField(
                controller: _textController,
                style: const TextStyle(color: Color(0xFFE0C9A6)),
                decoration: InputDecoration(
                  hintText: 'Type a message...',
                  hintStyle: TextStyle(
                      color: const Color(0xFFE0C9A6).withOpacity(0.5)),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(20),
                    borderSide: BorderSide(
                      color: const Color(0xFFE0C9A6).withOpacity(0.15),
                    ),
                  ),
                  filled: true,
                  fillColor: const Color(0xFF1C1C1E),
                  contentPadding: const EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 8,
                  ),
                ),
                onSubmitted: (_) => _handleSendMessage(),
              ),
            ),
            const SizedBox(width: 8),
            IconButton(
              icon: const Icon(Icons.send, color: Color(0xFFE0C9A6)),
              onPressed: _handleSendMessage,
            ),
          ],
        ),
      ),
    );
  }
}

class ChatMessage {
  final VirtualCompanion companion;
  final String message;
  final bool isCard;

  ChatMessage({
    required this.companion,
    required this.message,
    required this.isCard,
  });
}
