import 'package:flutter/material.dart';
import 'package:camera/camera.dart';
import '../models/virtual_companion.dart';

class VideoCallScreen extends StatefulWidget {
  final VirtualCompanion companion;

  const VideoCallScreen({
    super.key,
    required this.companion,
  });

  @override
  State<VideoCallScreen> createState() => _VideoCallScreenState();
}

class _VideoCallScreenState extends State<VideoCallScreen> {
  CameraController? _cameraController;
  bool _isCameraInitialized = false;
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    _initializeCamera();
  }

  Future<void> _initializeCamera() async {
    try {
      final cameras = await availableCameras();
      if (cameras.isEmpty) {
        setState(() => _errorMessage = 'No cameras available');
        return;
      }

      final frontCamera = cameras.firstWhere(
        (camera) => camera.lensDirection == CameraLensDirection.front,
        orElse: () => cameras.first,
      );

      _cameraController = CameraController(
        frontCamera,
        ResolutionPreset.medium,
        enableAudio: true,
      );

      await _cameraController?.initialize();
      if (mounted) {
        setState(() {
          _isCameraInitialized = true;
          _errorMessage = null;
        });
      }
    } catch (e) {
      setState(() {
        _errorMessage = 'Error initializing camera: $e';
        debugPrint(_errorMessage);
      });
    }
  }

  @override
  void dispose() {
    if (_cameraController != null) {
      _cameraController?.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF1C1C1E),
      body: Stack(
        children: [
          // Companion's "video" (placeholder)
          Container(
            width: double.infinity,
            height: double.infinity,
            color: const Color(0xFF2C2C2E),
            child: Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  CircleAvatar(
                    radius: 60,
                    backgroundImage:
                        AssetImage(widget.companion.profileImagePath),
                  ),
                  const SizedBox(height: 24),
                  Text(
                    'Waiting for ${widget.companion.displayName}...',
                    style: const TextStyle(
                      color: Color(0xFFE0C9A6),
                      fontSize: 18,
                    ),
                  ),
                  const SizedBox(height: 16),
                  const CircularProgressIndicator(
                    valueColor:
                        AlwaysStoppedAnimation<Color>(Color(0xFFE0C9A6)),
                  ),
                ],
              ),
            ),
          ),

          // Local video preview
          if (_isCameraInitialized && _cameraController != null)
            Positioned(
              top: 48,
              right: 16,
              child: Container(
                width: 120,
                height: 160,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: const Color(0xFFE0C9A6),
                    width: 2,
                  ),
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(10),
                  child: CameraPreview(_cameraController!),
                ),
              ),
            ),

          // Call controls
          Positioned(
            bottom: 48,
            left: 0,
            right: 0,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                _buildCallButton(
                  icon: Icons.mic,
                  onPressed: () {},
                ),
                const SizedBox(width: 24),
                _buildCallButton(
                  icon: Icons.call_end,
                  backgroundColor: Colors.red,
                  onPressed: () => Navigator.of(context).pop(),
                ),
                const SizedBox(width: 24),
                _buildCallButton(
                  icon: Icons.videocam,
                  onPressed: () {},
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCallButton({
    required IconData icon,
    Color? backgroundColor,
    required VoidCallback onPressed,
  }) {
    return Container(
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: backgroundColor ?? const Color(0xFF2C2C2E),
      ),
      child: IconButton(
        icon: Icon(icon),
        color: const Color(0xFFE0C9A6),
        iconSize: 32,
        onPressed: onPressed,
      ),
    );
  }
}
