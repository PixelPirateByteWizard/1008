import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../data/companion_profiles.dart';
import '../models/virtual_companion.dart';
import 'dart:math';
import '../models/ai_assistant_service.dart';
import 'chat_screen.dart';
import '../models/chat_message.dart';
import 'companion_profile_screen.dart';
import '../services/companion_service.dart';

class TopicBadge {
  final String label;
  final Color startColor;
  final Color endColor;
  final IconData icon;

  const TopicBadge({
    required this.label,
    required this.startColor,
    required this.endColor,
    required this.icon,
  });
}

final List<TopicBadge> topicBadges = [
  TopicBadge(
    label: 'TOP',
    startColor: Color(0xFFFF6B6B),
    endColor: Color(0xFFFF8E8E),
    icon: Icons.star_rounded,
  ),
  TopicBadge(
    label: 'FEATURED',
    startColor: Color(0xFF4ECDC4),
    endColor: Color(0xFF45B7AF),
    icon: Icons.diamond_rounded,
  ),
  TopicBadge(
    label: 'POPULAR',
    startColor: Color(0xFFFFBE0B),
    endColor: Color(0xFFFFA200),
    icon: Icons.local_fire_department_rounded,
  ),
  TopicBadge(
    label: 'NEW',
    startColor: Color(0xFF9B89B3),
    endColor: Color(0xFF7E6C96),
    icon: Icons.new_releases_rounded,
  ),
];

class QuickChatScreen extends StatefulWidget {
  const QuickChatScreen({super.key});

  @override
  State<QuickChatScreen> createState() => _QuickChatScreenState();
}

class _QuickChatScreenState extends State<QuickChatScreen> {
  Widget _buildTipItem({required IconData icon, required String text}) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: const Color(0xFFE0C9A6).withOpacity(0.1),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Icon(
            icon,
            color: const Color(0xFFE0C9A6),
            size: 18,
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Text(
            text,
            style: TextStyle(
              color: const Color(0xFFE0C9A6).withOpacity(0.9),
              fontSize: 14,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildTipSection({
    required String title,
    required List<Map<String, dynamic>> tips,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: const TextStyle(
            color: Color(0xFFE0C9A6),
            fontSize: 16,
            fontWeight: FontWeight.w600,
            letterSpacing: 0.5,
          ),
        ),
        const SizedBox(height: 12),
        ...tips.map((tip) => Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: _buildTipItem(
                icon: tip['icon'],
                text: tip['text'],
              ),
            )),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              const Color(0xFF1C1C1E),
              const Color(0xFF2C2C2E),
            ],
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.2),
              blurRadius: 8,
              spreadRadius: 1,
            ),
          ],
        ),
        child: SafeArea(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 24),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Text(
                          'Today\'s Topics',
                          style: Theme.of(context)
                              .textTheme
                              .headlineMedium
                              ?.copyWith(
                                fontWeight: FontWeight.w600,
                                color: const Color(0xFFE0C9A6),
                                letterSpacing: 1.2,
                              ),
                        ),
                        const Spacer(),
                        IconButton(
                          onPressed: () {
                            showDialog(
                              context: context,
                              builder: (context) => AlertDialog(
                                backgroundColor: const Color(0xFF2C2C2E),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(20),
                                  side: BorderSide(
                                    color: const Color(0xFFE0C9A6)
                                        .withOpacity(0.2),
                                    width: 1,
                                  ),
                                ),
                                title: Row(
                                  children: [
                                    Container(
                                      padding: const EdgeInsets.all(8),
                                      decoration: BoxDecoration(
                                        color: const Color(0xFFE0C9A6)
                                            .withOpacity(0.1),
                                        borderRadius: BorderRadius.circular(12),
                                      ),
                                      child: const Icon(
                                        Icons.tips_and_updates_outlined,
                                        color: Color(0xFFE0C9A6),
                                        size: 24,
                                      ),
                                    ),
                                    const SizedBox(width: 12),
                                    const Text(
                                      'Feature Guide',
                                      style: TextStyle(
                                        color: Color(0xFFE0C9A6),
                                        fontWeight: FontWeight.bold,
                                        letterSpacing: 0.5,
                                      ),
                                    ),
                                  ],
                                ),
                                content: SingleChildScrollView(
                                  child: Column(
                                    mainAxisSize: MainAxisSize.min,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      _buildTipSection(
                                        title: 'Basic Features',
                                        tips: [
                                          {
                                            'icon': Icons.chat_bubble_outline,
                                            'text':
                                                'Click "Start Chat" to have a brief conversation with the sage, limited to 3 rounds',
                                          },
                                          {
                                            'icon': Icons.explore_outlined,
                                            'text':
                                                'Use "Chat" button to enter full conversation mode',
                                          },
                                          {
                                            'icon': Icons.bookmark_border,
                                            'text':
                                                'Click the bookmark icon to save interesting sages for later',
                                          },
                                        ],
                                      ),
                                      const SizedBox(height: 16),
                                      _buildTipSection(
                                        title: 'Sage Tags',
                                        tips: [
                                          {
                                            'icon': Icons.star_rounded,
                                            'text':
                                                'TOP tag indicates most popular sages',
                                          },
                                          {
                                            'icon': Icons.diamond_rounded,
                                            'text':
                                                'FEATURED tag represents specially curated topics',
                                          },
                                          {
                                            'icon': Icons
                                                .local_fire_department_rounded,
                                            'text':
                                                'POPULAR tag shows recently trending sages',
                                          },
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                                actions: [
                                  TextButton(
                                    onPressed: () =>
                                        Navigator.of(context).pop(),
                                    style: TextButton.styleFrom(
                                      backgroundColor: const Color(0xFFE0C9A6)
                                          .withOpacity(0.1),
                                      shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(8),
                                      ),
                                    ),
                                    child: const Text(
                                      'Got it',
                                      style: TextStyle(
                                        color: Color(0xFFE0C9A6),
                                        fontWeight: FontWeight.w600,
                                        letterSpacing: 0.5,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            );
                          },
                          icon: Container(
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                              color: const Color(0xFFE0C9A6).withOpacity(0.1),
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(
                                color: const Color(0xFFE0C9A6).withOpacity(0.2),
                                width: 1,
                              ),
                            ),
                            child: const Icon(
                              Icons.help_outline_rounded,
                              color: Color(0xFFE0C9A6),
                              size: 20,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Talk to the sage, explore the past and present',
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                            color: const Color(0xFFE0C9A6).withOpacity(0.7),
                            letterSpacing: 0.5,
                          ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),
              Expanded(
                child: ListView.builder(
                  padding: const EdgeInsets.symmetric(horizontal: 24),
                  itemCount: companionProfiles.length,
                  itemBuilder: (context, index) {
                    final companion = companionProfiles[index];
                    return TopicCard(companion: companion);
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class TopicCard extends StatefulWidget {
  final VirtualCompanion companion;
  final TopicBadge? badge;

  TopicCard({
    super.key,
    required this.companion,
  }) : badge = topicBadges[Random().nextInt(topicBadges.length)];

  @override
  State<TopicCard> createState() => _TopicCardState();
}

class _TopicCardState extends State<TopicCard> {
  Widget _buildBadge() {
    return Container(
      margin: const EdgeInsets.only(left: 8),
      padding: const EdgeInsets.symmetric(
        horizontal: 8,
        vertical: 2,
      ),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            widget.badge!.startColor,
            widget.badge!.endColor,
          ],
        ),
        borderRadius: BorderRadius.circular(4),
        boxShadow: [
          BoxShadow(
            color: widget.badge!.startColor.withOpacity(0.3),
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            widget.badge!.icon,
            size: 14,
            color: Colors.white,
          ),
          const SizedBox(width: 4),
          Text(
            widget.badge!.label,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 12,
              fontWeight: FontWeight.w500,
              letterSpacing: 0.5,
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            const Color(0xFF2C2C2E),
            const Color(0xFF1C1C1E),
          ],
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: const Color(0xFFE0C9A6).withOpacity(0.15),
          width: 0.5,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.3),
            blurRadius: 15,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(20),
          onTap: () {
            // TODO: 实现卡片点击效果
          },
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: const Color(0xFFE0C9A6).withOpacity(0.3),
                          width: 2,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: const Color(0xFFE0C9A6).withOpacity(0.1),
                            blurRadius: 10,
                            spreadRadius: 2,
                          ),
                        ],
                      ),
                      child: GestureDetector(
                        onTap: () {
                          Navigator.of(context).push(
                            MaterialPageRoute(
                              builder: (context) => CompanionProfileScreen(
                                companion: widget.companion,
                              ),
                            ),
                          );
                        },
                        child: CircleAvatar(
                          radius: 28,
                          backgroundImage:
                              AssetImage(widget.companion.profileImagePath),
                        ),
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Expanded(
                                child: Text(
                                  widget.companion.displayName,
                                  style: Theme.of(context)
                                      .textTheme
                                      .titleLarge
                                      ?.copyWith(
                                        fontWeight: FontWeight.bold,
                                        color: const Color(0xFFE0C9A6),
                                        letterSpacing: 0.5,
                                      ),
                                ),
                              ),
                              _buildBadge(),
                            ],
                          ),
                          const SizedBox(height: 4),
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 8,
                              vertical: 2,
                            ),
                            decoration: BoxDecoration(
                              color: const Color(0xFFE0C9A6).withOpacity(0.1),
                              borderRadius: BorderRadius.circular(4),
                            ),
                            child: const Text(
                              'Online · Sage',
                              style: TextStyle(
                                color: Color(0xFFE0C9A6),
                                fontSize: 12,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: const Color(0xFF2C2C2E),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: const Color(0xFFE0C9A6).withOpacity(0.1),
                      width: 0.5,
                    ),
                  ),
                  child: Text(
                    widget.companion.passionForLife,
                    style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                          color: const Color(0xFFE0C9A6).withOpacity(0.9),
                          height: 1.5,
                          letterSpacing: 0.3,
                        ),
                  ),
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: ElevatedButton(
                        onPressed: () {
                          showDialog(
                            context: context,
                            builder: (context) =>
                                ChatDialog(companion: widget.companion),
                          );
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor:
                              const Color(0xFFB8860B).withOpacity(0.8),
                          foregroundColor: const Color(0xFFE0C9A6),
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                          elevation: 0,
                        ),
                        child: const Text(
                          'Start Chat',
                          style: TextStyle(letterSpacing: 1),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Container(
                      decoration: BoxDecoration(
                        border: Border.all(
                          color: const Color(0xFFE0C9A6).withOpacity(0.3),
                          width: 0.5,
                        ),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: FutureBuilder<List<String>>(
                        future: CompanionService().getAddedCompanionIds(),
                        builder: (context, snapshot) {
                          final isAdded = snapshot.hasData &&
                              snapshot.data!
                                  .contains(widget.companion.identifier);

                          return IconButton(
                            onPressed: () async {
                              if (isAdded) {
                                await CompanionService().removeCompanion(
                                    widget.companion.identifier);
                              } else {
                                await CompanionService()
                                    .addCompanion(widget.companion.identifier);
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    content: Text(
                                        '${widget.companion.displayName} has been added to your chat list'),
                                    backgroundColor: const Color(0xFFB8860B)
                                        .withOpacity(0.8),
                                  ),
                                );
                              }
                              setState(() {}); // Now this will work
                            },
                            icon: Icon(
                              isAdded ? Icons.person_remove : Icons.person_add,
                              color: const Color(0xFFE0C9A6),
                            ),
                            style: IconButton.styleFrom(
                              backgroundColor: const Color(0xFF2C2C2E),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class ChatDialog extends StatefulWidget {
  final VirtualCompanion companion;

  const ChatDialog({
    super.key,
    required this.companion,
  });

  @override
  State<ChatDialog> createState() => _ChatDialogState();
}

class _ChatDialogState extends State<ChatDialog> {
  final TextEditingController _messageController = TextEditingController();
  final List<ChatMessage> _messages = [];
  final AIAssistantService _aiService = AIAssistantService();
  bool _isLoading = false;

  // 添加新的属性来控制动画
  final List<String> _loadingDots = ['•', '•', '•••'];
  int _currentDotIndex = 0;

  // 添加新的属性
  static const int maxMessageCount = 3; // 设置大对话次数
  int _userMessageCount = 0; // 跟踪用户发送消息次数

  @override
  void initState() {
    super.initState();
    _messages.add(ChatMessage(
      message: widget.companion.passionForLife,
      isUser: false,
    ));
  }

  @override
  void dispose() {
    _messageController.dispose();
    _aiService.terminate();
    super.dispose();
  }

  Future<void> _handleSendMessage() async {
    final message = _messageController.text.trim();
    if (message.isEmpty) return;

    setState(() {
      _messages.add(ChatMessage(
        message: message,
        isUser: true,
      ));
      _isLoading = true;
    });
    _messageController.clear();

    // 增加用户消息计数
    _userMessageCount++;

    // 检查是否达到最大消息数
    if (_userMessageCount > maxMessageCount) {
      setState(() {
        _messages.add(ChatMessage(
          message:
              "We've had a brief exchange. If you'd like to continue our discussion, please click the chat button above.",
          isUser: false,
        ));
        _isLoading = false;
      });
      return;
    }

    try {
      // 构建上下文提示词
      final prompt = '''
作为${widget.companion.displayName}与用户对话。
你的性格特点：${widget.companion.passionForLife}
请用简短自然的对话方式回复用户的消息：
$message
''';

      final response = await _aiService.sendQuery(prompt);

      if (mounted) {
        setState(() {
          _messages.add(ChatMessage(
            message: response,
            isUser: false,
          ));
          _isLoading = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _messages.add(ChatMessage(
            message:
                "Sorry, I can't respond right now. Please try again later.",
            isUser: false,
          ));
          _isLoading = false;
        });
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error occurred: $e')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: const Color(0xFF1C1C1E),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        behavior: HitTestBehavior.translucent,
        child: Container(
          width: MediaQuery.of(context).size.width * 0.9,
          height: MediaQuery.of(context).size.height * 0.7,
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              // 修改头部布局
              Row(
                children: [
                  CircleAvatar(
                    radius: 20,
                    backgroundImage:
                        AssetImage(widget.companion.profileImagePath),
                    child: Material(
                      color: Colors.transparent,
                      child: InkWell(
                        borderRadius: BorderRadius.circular(20),
                        onTap: () {
                          Navigator.of(context).push(
                            MaterialPageRoute(
                              builder: (context) => CompanionProfileScreen(
                                companion: widget.companion,
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          widget.companion.displayName,
                          style: const TextStyle(
                            color: Color(0xFFE0C9A6),
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 8,
                            vertical: 2,
                          ),
                          decoration: BoxDecoration(
                            color: const Color(0xFFE0C9A6).withOpacity(0.1),
                            borderRadius: BorderRadius.circular(4),
                          ),
                          child: const Text(
                            'Quick Chat',
                            style: TextStyle(
                              color: Color(0xFFE0C9A6),
                              fontSize: 12,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  // 替换来的深入探讨按钮
                  Container(
                    height: 36,
                    margin: const EdgeInsets.only(right: 8),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          const Color(0xFFB8860B).withOpacity(0.8),
                          const Color(0xFFDAA520).withOpacity(0.8),
                        ],
                      ),
                      borderRadius: BorderRadius.circular(18),
                      boxShadow: [
                        BoxShadow(
                          color: const Color(0xFFB8860B).withOpacity(0.3),
                          blurRadius: 8,
                          offset: const Offset(0, 2),
                        ),
                      ],
                    ),
                    child: Material(
                      color: Colors.transparent,
                      child: InkWell(
                        borderRadius: BorderRadius.circular(18),
                        onTap: () {
                          Navigator.of(context).pop();
                          Navigator.of(context).push(
                            MaterialPageRoute(
                              builder: (context) => ChatScreen(
                                companion: widget.companion,
                                previousMessages: _messages,
                              ),
                            ),
                          );
                        },
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 12),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const Icon(
                                Icons.chat_outlined,
                                color: Colors.white,
                                size: 16,
                              ),
                              const SizedBox(width: 4),
                              Text(
                                'Chat',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 13,
                                  fontWeight: FontWeight.w500,
                                  letterSpacing: 0.5,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  IconButton(
                    onPressed: () => Navigator.of(context).pop(),
                    icon: const Icon(Icons.close, color: Color(0xFFE0C9A6)),
                  ),
                ],
              ),
              const Divider(color: Color(0xFFE0C9A6), thickness: 0.5),
              // 聊天消息列表
              Expanded(
                child: ListView.builder(
                  reverse: true,
                  itemCount: _messages.length + (_isLoading ? 1 : 0),
                  itemBuilder: (context, index) {
                    if (_isLoading && index == 0) {
                      return TypingIndicator(companion: widget.companion);
                    }
                    final messageIndex = _isLoading ? index - 1 : index;
                    final message =
                        _messages[_messages.length - 1 - messageIndex];
                    return ChatBubble(
                      message: message,
                      companion: widget.companion,
                    );
                  },
                ),
              ),
              // 输入框
              Container(
                padding: const EdgeInsets.symmetric(vertical: 8),
                child: Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: _messageController,
                        enabled:
                            !_isLoading && _userMessageCount <= maxMessageCount,
                        style: const TextStyle(color: Color(0xFFE0C9A6)),
                        maxLength: 100,
                        maxLengthEnforcement: MaxLengthEnforcement.enforced,
                        minLines: 1,
                        maxLines: 4,
                        decoration: InputDecoration(
                          hintText: _userMessageCount > maxMessageCount
                              ? 'Chat limit reached, click Chat for deep discussion'
                              : 'Type a message...',
                          hintStyle: TextStyle(
                            color: const Color(0xFFE0C9A6).withOpacity(0.5),
                          ),
                          filled: true,
                          fillColor: const Color(0xFF2C2C2E),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(20),
                            borderSide: BorderSide.none,
                          ),
                          contentPadding: const EdgeInsets.symmetric(
                            horizontal: 16,
                            vertical: 8,
                          ),
                          counterText: '', // 隐藏字符计数器
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    IconButton(
                      onPressed:
                          (_isLoading || _userMessageCount > maxMessageCount)
                              ? null
                              : _handleSendMessage,
                      icon: Icon(
                        Icons.send_rounded,
                        color:
                            (_isLoading || _userMessageCount > maxMessageCount)
                                ? const Color(0xFFE0C9A6).withOpacity(0.3)
                                : const Color(0xFFE0C9A6),
                      ),
                      style: IconButton.styleFrom(
                        backgroundColor:
                            (_isLoading || _userMessageCount > maxMessageCount)
                                ? const Color(0xFF2C2C2E).withOpacity(0.5)
                                : Colors.transparent,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class ChatBubble extends StatelessWidget {
  final ChatMessage message;
  final VirtualCompanion companion;

  const ChatBubble({
    super.key,
    required this.message,
    required this.companion,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment:
            message.isUser ? MainAxisAlignment.end : MainAxisAlignment.start,
        children: [
          if (!message.isUser) ...[
            GestureDetector(
              onTap: () {
                Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (context) => CompanionProfileScreen(
                      companion: companion,
                    ),
                  ),
                );
              },
              child: CircleAvatar(
                radius: 16,
                backgroundImage: AssetImage(companion.profileImagePath),
              ),
            ),
            const SizedBox(width: 8),
          ],
          Container(
            constraints: BoxConstraints(
              maxWidth: MediaQuery.of(context).size.width * 0.6,
            ),
            padding: const EdgeInsets.symmetric(
              horizontal: 16,
              vertical: 10,
            ),
            decoration: BoxDecoration(
              color: message.isUser
                  ? const Color(0xFFB8860B).withOpacity(0.8)
                  : const Color(0xFF2C2C2E),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Text(
              message.message,
              style: const TextStyle(
                color: Color(0xFFE0C9A6),
                fontSize: 14,
              ),
            ),
          ),
          if (message.isUser) const SizedBox(width: 8),
        ],
      ),
    );
  }
}

// 新增自定义打字指示器组件
class TypingIndicator extends StatefulWidget {
  final VirtualCompanion companion;

  const TypingIndicator({
    super.key,
    required this.companion,
  });

  @override
  State<TypingIndicator> createState() => _TypingIndicatorState();
}

class _TypingIndicatorState extends State<TypingIndicator>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  final List<Animation<double>> _dotAnimations = [];

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat();

    // 创建三个点的动画
    for (int i = 0; i < 3; i++) {
      _dotAnimations.add(
        Tween<double>(begin: 0, end: 1).animate(
          CurvedAnimation(
            parent: _controller,
            curve: Interval(
              i * 0.2,
              0.6 + i * 0.2,
              curve: Curves.easeInOut,
            ),
          ),
        ),
      );
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(8),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          CircleAvatar(
            radius: 16,
            backgroundImage: AssetImage(widget.companion.profileImagePath),
          ),
          const SizedBox(width: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: BoxDecoration(
              color: const Color(0xFF2C2C2E),
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.1),
                  blurRadius: 8,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: List.generate(3, (index) {
                return AnimatedBuilder(
                  animation: _controller,
                  builder: (context, child) {
                    return Container(
                      width: 8,
                      height: 8,
                      margin: const EdgeInsets.symmetric(horizontal: 2),
                      decoration: BoxDecoration(
                        color: Color(0xFFE0C9A6).withOpacity(
                          _dotAnimations[index].value,
                        ),
                        shape: BoxShape.circle,
                      ),
                    );
                  },
                );
              }),
            ),
          ),
        ],
      ),
    );
  }
}
