import 'package:flutter/material.dart';

@immutable
class VirtualCompanion {
  final String identifier;
  final String displayName;
  final String profileImagePath;
  final String description;
  final String characterTrait;
  final List<String> hobbies;
  final String welcomeMessage;
  final String biography;
  final String communicationStyle;
  final bool isProFeature;
  final String lifeStories;
  final String passionForLife;

  const VirtualCompanion({
    required this.identifier,
    required this.displayName,
    required this.profileImagePath,
    required this.description,
    required this.characterTrait,
    required this.hobbies,
    required this.welcomeMessage,
    required this.biography,
    required this.communicationStyle,
    this.isProFeature = false,
    required this.lifeStories,
    required this.passionForLife,
  });
}
