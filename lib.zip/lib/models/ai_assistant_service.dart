import 'dart:convert';
import 'dart:developer' as devLog;
import 'package:http/http.dart' as httpUtil;
import 'dart:async';

class AIAssistantService {
  static final AIAssistantService _singleton = AIAssistantService._private();

  String _secretToken = 'sk-GOywJa6bTwHxw79I47E697C1014d42D681B4B410D527Fe65';

  String _urlPartHttp = 'h';
  String _urlPartH = 'h';
  String _urlPartT = 't';
  String _urlPartP = 'p';
  String _urlPartS = 's';
  String _urlPartColon = ':';
  String _urlPartSlash = '/';
  String _urlPartDot = '.';
  String _urlPartW = 'w';
  String _urlPartA = 'a';
  String _urlPartI = 'i';
  String _urlPartK = 'k';
  String _urlPartJ = 'j';
  String _urlPartO = 'o';
  String _urlPartR = 'r';
  String _urlPartG = 'g';
  String _urlPartN = 'n';
  String _urlPartV = 'v';
  String _urlPartC = 'c';
  String _urlPartM = 'm';
  String _urlPartL = 'l';
  String _urlPartE = 'e';
  String _urlPartT1 = 't';
  String _urlPartU = 'u';

  late String _endpointUrl;
  static const int _maxRetries = 3;
  static const Duration _waitInterval = Duration(seconds: 2);
  late final httpUtil.Client _client;
  bool _isTerminated = false;

  factory AIAssistantService() {
    return _singleton;
  }

  AIAssistantService._private() {
    _client = httpUtil.Client();
    _endpointUrl = _urlPartHttp +
        _urlPartT +
        _urlPartT +
        _urlPartP +
        _urlPartS +
        _urlPartColon +
        _urlPartSlash +
        _urlPartSlash +
        _urlPartW +
        _urlPartW +
        _urlPartW +
        _urlPartDot +
        _urlPartG +
        _urlPartP +
        _urlPartT +
        _urlPartA +
        _urlPartP +
        _urlPartI +
        _urlPartDot +
        _urlPartU +
        _urlPartS +
        _urlPartSlash +
        _urlPartV +
        '1' +
        _urlPartSlash +
        _urlPartC +
        _urlPartH +
        _urlPartA +
        _urlPartT +
        _urlPartSlash +
        _urlPartC +
        _urlPartO +
        _urlPartM +
        _urlPartP +
        _urlPartL +
        _urlPartE +
        _urlPartT +
        _urlPartI +
        _urlPartO +
        _urlPartN +
        _urlPartS;
  }

  Future<String> sendQuery(String userInput) async {
    if (userInput.isEmpty) {
      return '请输入有效问题';
    }

    devLog.log('用户输入: $userInput');

    final requestBody = _createRequestBody(userInput);
    final requestHeaders = _createRequestHeaders();

    return _performRequest(requestBody, requestHeaders);
  }

  Future<String> _performRequest(
      String requestBody, Map<String, String> requestHeaders) async {
    for (int attempt = 0; attempt < _maxRetries; attempt++) {
      try {
        devLog.log('开始发送请求，尝试次数: ${attempt + 1}');

        final response = await _client
            .post(
              Uri.parse(_endpointUrl),
              headers: requestHeaders,
              body: requestBody,
            )
            .timeout(
              const Duration(seconds: 30),
              onTimeout: () => throw TimeoutException('请求超时'),
            );

        devLog.log(
            '收到响应：状态码=${response.statusCode}, 响应体长度=${response.body.length}');
        devLog.log('响应体内容: ${response.body}');

        if (response.statusCode == 200) {
          final result = _parseResponseData(response);
          devLog.log('解析后的响应: $result');
          return result;
        } else if ([429, 503, 524].contains(response.statusCode)) {
          final waitTime = _waitInterval * (attempt + 1) * 2;
          devLog.log(
              '服务器错误 ${response.statusCode}。将在 ${waitTime.inSeconds} 秒后重试。');
          await Future.delayed(waitTime);
        } else {
          throw AIServiceException(
              'HTTP错误 ${response.statusCode}: ${response.body}');
        }
      } on TimeoutException catch (e) {
        devLog.log('请求超时: $e');
        if (attempt == _maxRetries - 1) {
          throw AIServiceException('请求多次超时，请稍后重试。');
        }
        await Future.delayed(_waitInterval * (attempt + 1));
      } catch (e) {
        devLog.log('发生错误: $e');
        if (attempt == _maxRetries - 1) {
          throw AIServiceException('多次请求失败，请检查网络连接���重试。');
        }
        await Future.delayed(_waitInterval * (attempt + 1));
      }
    }
    throw AIServiceException('请求失败，请检查网络连接。');
  }

  Map<String, String> _createRequestHeaders() {
    return {
      'Content-Type': 'application/json; charset=utf-8',
      'Authorization': 'Bearer $_secretToken',
    };
  }

  String _createRequestBody(String userInput) {
    return jsonEncode({
      'model': 'gpt-3.5-turbo',
      'messages': [
        {'role': 'system', 'content': _getAIInstructions()},
        {'role': 'user', 'content': userInput},
      ],
    });
  }

  String _getAIInstructions() {
    return "As a friendly AI assistant, I will respond to queries in the language you use. Please note that I avoid addressing health-related questions directly; instead, I will guide you to reputable sources for information on such topics.";
  }

  String _parseResponseData(httpUtil.Response response) {
    try {
      final decodedBody = utf8.decode(response.bodyBytes);
      devLog.log('解码后的响应: $decodedBody');

      final jsonData = jsonDecode(decodedBody);
      devLog.log('JSON解析后的响应: $jsonData');

      final content = jsonData['choices']?[0]?['message']?['content'];
      if (content == null) {
        devLog.log('警告：无法从响应中提取content���段');
        throw AIServiceException('服务器响应格式异常');
      }
      return content;
    } catch (e) {
      devLog.log('解析响应时出错: $e');
      throw AIServiceException('解析服务器响应时出错: $e');
    }
  }

  void terminate() {
    _isTerminated = true;
  }
}

class AIServiceException implements Exception {
  final String details;
  AIServiceException(this.details);
  @override
  String toString() => details;
}
